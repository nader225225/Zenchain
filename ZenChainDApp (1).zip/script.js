let isConnected = false;
let account = null;
let gmCooldown = 24 * 60 * 60 * 1000; // 24 ساعت
let lastGMSent = 0;

// دکمه‌ها
const connectWalletBtn = document.getElementById('connectWalletBtn');
const faucetBtn = document.getElementById('faucetBtn');
const sendGMBtn = document.getElementById('sendGMBtn');
const timer = document.getElementById('timer');
const totalGM = document.getElementById('totalGM');
const gmList = document.getElementById('gmList');
const mintNFT = document.getElementById('mintNFT');

// اتصال / قطع کیف پول
connectWalletBtn.addEventListener('click', () => {
  if (!isConnected) {
    // شبیه‌سازی اتصال
    account = '0x1234...ABCD';
    isConnected = true;
    connectWalletBtn.textContent = 'قطع اتصال کیف پول';
    alert('کیف پول وصل شد: ' + account);
  } else {
    isConnected = false;
    account = null;
    connectWalletBtn.textContent = 'اتصال کیف پول';
    alert('کیف پول قطع شد');
  }
});

// Faucet (باز کردن لینک شبیه‌سازی)
faucetBtn.addEventListener('click', () => {
  window.open('https://example-faucet.com', '_blank');
});

// ارسال GM
sendGMBtn.addEventListener('click', () => {
  const now = Date.now();
  if (now - lastGMSent < gmCooldown) {
    alert('فعلاً نمی‌توانید GM بفرستید. لطفاً صبر کنید.');
    return;
  }

  lastGMSent = now;
  updateGMCooldown();

  addGM(account || '0xUser', new Date());
  alert('GM ارسال شد!');
});

// تایمر GM
function updateGMCooldown() {
  sendGMBtn.disabled = true;
  const interval = setInterval(() => {
    const remaining = gmCooldown - (Date.now() - lastGMSent);
    if (remaining <= 0) {
      sendGMBtn.disabled = false;
      timer.textContent = '';
      clearInterval(interval);
    } else {
      const hours = Math.floor(remaining / (1000 * 60 * 60));
      const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((remaining % (1000 * 60)) / 1000);
      timer.textContent = `دوباره در: ${hours}س ${minutes}د ${seconds}ث فعال می‌شود`;
    }
  }, 1000);
}

// اضافه کردن GM به لیست
function addGM(user, date) {
  const li = document.createElement('li');
  li.textContent = `${user} - ${date.toLocaleString()}`;
  gmList.prepend(li);
  totalGM.textContent = parseInt(totalGM.textContent) + 1;
}

// مینت NFT (شبیه‌سازی باز کردن لینک)
mintNFT.addEventListener('click', () => {
  window.open('https://example-nft-mint.com', '_blank');
});
